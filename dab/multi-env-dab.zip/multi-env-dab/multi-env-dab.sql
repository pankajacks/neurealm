-- Databricks notebook source
-- MAGIC %python
-- MAGIC print("hi")

-- COMMAND ----------

USE CATALOG dev_catalog;

-- COMMAND ----------

SELECT count(*) from health_bronze;

-- COMMAND ----------

use catalog prod_catalog;

-- COMMAND ----------

select count(*) from health_bronze

-- COMMAND ----------

