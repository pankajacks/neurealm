-- Databricks notebook source
USE CATALOG dab;

-- COMMAND ----------

SHOW TABLES;

-- COMMAND ----------

SELECT count(*) FROM health_bronze;

-- COMMAND ----------

-- MAGIC %python
-- MAGIC
-- MAGIC spark.table('health_bronze').printSchema()

-- COMMAND ----------

-- MAGIC %python
-- MAGIC
-- MAGIC spark.table('health_silver').printSchema()

-- COMMAND ----------

